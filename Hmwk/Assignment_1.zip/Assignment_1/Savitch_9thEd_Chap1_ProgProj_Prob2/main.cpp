/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on June 23, 2015, 8:48 PM
 * Purpose: Homework, CS!
 */

//System Libraries
#include <iostream> //File I/O
using namespace std; //std namespace -> iostream

//User Libraries

//Global constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables Here
    
    //Input Values Here

    //This took forever...
    cout<<"*************************************"<<endl;
    cout<<endl;
    cout<<"      C C C          S S S S      !!"<<endl;
    cout<<"     C     C        S       S     !!"<<endl;
    cout<<"    C              S              !!"<<endl;
    cout<<"   C                S             !!"<<endl;
    cout<<"   C                 S S S S      !!"<<endl;
    cout<<"   C                         S    !!"<<endl;
    cout<<"    C                         S   !!"<<endl;
    cout<<"     C      C       S        S    !!"<<endl;
    cout<<"      C    C         S      S       "<<endl;
    cout<<"        C C           S SS S      00"<<endl;
    cout<<endl;
    cout<<"*************************************"<<endl;
    cout<<endl;
    cout<<"   Computer Science is cool stuff!!"<<endl;  
    
    //Exit Stage Right!
    return 0;
}