/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 8, 2015, 11:53 PM
 * Purpose: Population
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    
    //Declare Variables
    float nOrgnsm;        //starting number of organisms
    float pIncrse;        //daily population increase (%)
    unsigned int nDays;   //number of days they will multiply
    float popIncr;        //population increase
    
    //User input starting number of organisms
    cout<<"What is the starting number of organisms?"<<endl;
    cin>>nOrgnsm;
    cout<<endl;
    
    //Validation: You can't have less than 2 starting organisms
    if(nOrgnsm<2){
        do{
            
            cout<<"You can't have less than 2 starting organisms"<<endl;
            cout<<"These organisms don't reproduce asexually"<<endl;
            cout<<"What is the starting number of organisms?"<<endl;
            cin>>nOrgnsm;
            
        }while(nOrgnsm<2);
    }
    
    //User input daily population increase by percent
    cout<<"What is the percentage of population increase per day?"<<endl;
    cin>>pIncrse;
    cout<<endl;
    
    //Validation: You can't have a negative percent increase
    if(pIncrse<0){
        do{
            
            cout<<"You can't have a negative percent increase"<<endl;
            cout<<"What is the percentage of population increase per day?"<<endl;
            cin>>pIncrse;
            cout<<endl;
            
        }while(pIncrse<0);
    }
    
    //User input number of days the organism will multiply
    cout<<"What is the number of days the population will increase?"<<endl;
    cin>>nDays;
    cout<<endl;
    
    //Validation: You can't put zero or a negative amount of days
    if(nDays<1){
        
        do{
            
            cout<<"You can't have zero or a negative amount of days"<<endl;
            cout<<"What is the number of days the population will increase?"<<endl;
            cin>>nDays;
            cout<<endl;
            
        }while(nDays<1);
    }
    
    //Output the heading of the table
    cout<<"Day     Population Size"<<endl;
    cout<<"-----------------------"<<endl;
    
    //Loop to display each day the organism increases
    for(unsigned int days=1;days<=nDays;days++){
        //Output table
        cout<<fixed<<showpoint<<setprecision(2);
        cout<<setw(3)<<days<<"        "<<setw(10)<<nOrgnsm<<endl;
        
        //Calculate the population increase
        popIncr=nOrgnsm*pIncrse/100.0f;
        nOrgnsm+=popIncr;
       
    }
    
    //Exit Stage Right!
    return 0;
}

