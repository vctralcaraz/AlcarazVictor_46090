/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 12, 2015, 1:34 PM
 * Purpose: Kinetic Energy
 */

//SystemLibraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
float kinEngy(unsigned int,unsigned int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int mass;    //weight of object in kilograms
    unsigned int velocty; //speed of object in meters per second m/s
    
    //User Input
    //Validation
    do{
    cout<<"What is the weight of the object (in kilograms)?"<<endl;
    cin>>mass;
    cout<<endl;
    if(mass<1)cout<<"You can't have a zero or negative mass"<<endl;
    }while(mass<1);
    
    do{
    cout<<"What is the speed of the object (in m/s)?"<<endl;
    cin>>velocty;
    cout<<endl;
    if(velocty<=0)cout<<"You can't have a zero or negative speed"<<endl;
    }while(velocty<=0);
    
    //Output the results
    cout<<"The kinetic energy of your object in motion is "<<kinEngy(mass,velocty)<<endl;
    
    //Exit Stage Right!
    return 0;
}

float kinEngy(unsigned int m,unsigned int v){
    float kEnergy;
    kEnergy=0.5*m*v*v;
    return kEnergy;
}