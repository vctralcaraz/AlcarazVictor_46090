/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 12, 2015, 11:17 PM
 * Purpose: Days Out
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
unsigned int numEply();
unsigned int numMiss(unsigned int);
float aveMiss(unsigned int,unsigned int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int employd=numEply();       //number of employees
    unsigned int missed=numMiss(employd); //total number of days missed
    
    //Output the results
    cout<<"Your employees had an average of "<<aveMiss(employd,missed)<<" days missed last year"<<endl;
    
    //Exit Stage Right!
    return 0;
}

/***************************************
 ************* aveMiss *****************
 ***************************************
 * Purpose: calculate average missed days
 * Input:
 *      numEply -> e
 *      numMiss -> m
 * Output:
 *      a       -> average missed days
 **************************************/
float aveMiss(unsigned int e,unsigned int m){
    float a;
    a=m/e;
    return a;
}

/***************************************
 ************* numMiss *****************
 ***************************************
 * Purpose: add total days missed
 * Input:
 *      numEply -> e
 * Output:
 *      t       -> total missed days
 **************************************/
unsigned int numMiss(unsigned int e){
    unsigned int m;
    unsigned int t=0;
    for(int i=1;i<=e;i++){
        cout<<"How many days has employee "<<i<<" missed?"<<endl;
        cin>>m;
        cout<<endl;
        
        t+=m;
    }
    return t;
}

/***************************************
 ************* numEply *****************
 ***************************************
 * Purpose: to get, from user, the number of employees
 * Input:
 *      n -> number of employees
 * Output:
 *      n -> number of employees
 **************************************/
unsigned int numEply(){
    unsigned int n;
    cout<<"How many employees are hired in your company?"<<endl;
    cin>>n;
    cout<<endl;
    return n;
}