/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 12, 2015, 2:16 PM
 * Purpose: Coin Flip
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
unsigned int coinFlp(unsigned int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variable
    unsigned int iters;  //how many times the coin will flip
    
    //User Input & validation
    do{
        cout<<"How many times do you want to flip the coin?"<<endl;
        cin>>iters;
        cout<<endl;
        if(iters<1){
            cout<<"You need to flip the coin at least once"<<endl;
        }
    }while(iters<1);
    
    //call function
    coinFlp(iters);
    
    return 0;
}

/******************************************
 *************  coinFlp  ******************
 ******************************************
 * Purpose: To calculate and output the heads and tails totals
 * Input:
 *      iters -> l
 *      h     -> adding heads
 *      t     -> adding tails
 *      n     -> random number
 * Output:
 *      h     -> total heads
 *      t     -> total tails
 */
unsigned int coinFlp(unsigned int l){
    srand(time(0));
    int h=0;
    int t=0;
    int n;
    for(int i=1;i<=l;i++){
        n=rand()%2;
        switch(n){
            case 0:{
                //cout<<"Heads!"<<endl;
                h++;
                break;
            }
            case 1:{
                //cout<<"Tails!"<<endl;
                t++;
                break;
            }
            default:{
                cout<<"Not Possible"<<endl;
                return 1;
            }
        }
    }
    cout<<"Total Heads = "<<h<<endl;
    cout<<"Total Tails = "<<t<<endl;
}