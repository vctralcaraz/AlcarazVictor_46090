/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 13, 2015, 1:05 AM
 * Purpose: To determine present value
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
unsigned int gtPstVl(unsigned int,unsigned short,unsigned short);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int fValue;  //amount of future value desired in $'s
    unsigned int iRate;   //interest rate gained for savings in %
    unsigned int years;   //years money is going to be saved
    
    //User input and validation
    do{
        cout<<"What is the goal of your savings? (in $'s)"<<endl;
        cin>>fValue;
        if(fValue<1){
            cout<<"You should be more ambitious with your future goals"<<endl;
        }
    }while(fValue<1);
    
    do{
        cout<<"How much is your interest rate going to be? (in %)"<<endl;
        cin>>iRate;
        if(iRate<1){
            cout<<"You shouldn't have a zero or negative interest rate"<<endl;
        }
    }while(iRate<1);
    
    do{
        cout<<"How many years are you going to put your money away for?"<<endl;
        cin>>years;
        if(years<1){
            cout<<"You need to save for at least one year"<<endl;
        }
    }while(years<1);
    
    //Output the results
    cout<<"You need to deposit $"<<gtPstVl(fValue,iRate,years)<<" into your savings today"<<endl;
    
    //Exit Stage Right!
    return 0;
}

unsigned int gtPstVl(unsigned int f,unsigned short r,unsigned short y){
    unsigned int p;
    unsigned int x=0;
    for(int i=1;i<=y;i++){
        x+=(1+(r/100));
    }
    p=f/x;
    return p;
}