/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 12, 2015, 11:42 AM
 * Purpose: Population per year
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
unsigned int getPopu(unsigned int,unsigned int,unsigned int,unsigned int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int sPopuli; //Starting population
    unsigned int nPopuli; //New population
    unsigned int bRate;   //birth rate in %
    unsigned int dRate;   //death rate in %
    unsigned int years;   //time span in years
    
    //Input
    cout<<"What is the starting population?"<<endl;
    cin>>sPopuli;
    cout<<"What is the annual birth rate (in %)?"<<endl;
    cin>>bRate;
    cout<<"What is the annual death rate (in %)?"<<endl;
    cin>>dRate;
    cout<<"How many years do you want to simulate?"<<endl;
    cin>>years;
    cout<<endl;
    
    //Output the heading
    cout<<"Starting Population = "<<sPopuli<<endl<<endl;
    cout<<"Year     New Population"<<endl;
    cout<<"-----------------------"<<endl;
    
    for(unsigned int i=1;i<=years;i++){
        getPopu(sPopuli,bRate,dRate,i);
    }
    return 0;
}

unsigned int getPopu(unsigned int p,unsigned int b,unsigned int d,unsigned int i){
    unsigned int n;
    n=(p+(b*p/100)-(d*p/100))*i;
    cout<<setw(3)<<i<<"     "<<setw(10)<<n<<endl;
}