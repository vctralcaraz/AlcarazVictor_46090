/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 12, 2015, 1:48 AM
 * Purpose: Retail Markup
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
float rMarkup(float,float);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float price;  //cost of item in $'s
    float markup; //markup of item in %
    
    //User input price of item and markup %
    do{
        cout<<"What is the initial cost of the item? (in $)"<<endl;
        cin>>price;

        //Validation
        if(price<0){
            cout<<"You can't have a negative cost"<<endl;
        }
    }while(price<0);
    
    do{
        cout<<"What is the mark up (in %) for retail?"<<endl;
        cin>>markup;

        //Validation
        if(markup<0){
            cout<<"You can't have a negative markup"<<endl;
        }
    }while(markup<0);
    
    //Output the results
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"For the item costing $"<<price<<" to produce and a markup of "<<markup<<"%,"<<endl;
    cout<<"the retail price comes to $"<<rMarkup(price,markup)<<endl;
    
    //Exit Stage Right!
    return 0;
}

/*******************************
 *********** rMarkup ***********
 *******************************
 * Purpose: To Calculate Markup
 * Input:
 *      price -> c
 *      markup -> m
 * Output:
 *      total -> retail value
 ******************************/
float rMarkup(float c,float m){
    float markup;
    float total;
    markup=c*(m/100.0);
    total=c+markup;
    return total;
}