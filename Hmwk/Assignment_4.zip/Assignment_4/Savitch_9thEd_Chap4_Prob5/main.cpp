/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 12, 2015, 12:17 AM
 * Purpose: Help maintain body weight
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
float getBMR(unsigned int);
float getPhys(unsigned int,unsigned int,unsigned int);
float getCons(unsigned int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Define Variables
    unsigned int weight;  //weight in pounds (lbs)
    unsigned int intense; //intensity level of physical activity
    unsigned int minutes; //time in minutes taken for physical activity
    unsigned int calorie; //calories consumed
    
    //User Input of weight, intensity, minutes, and calories consumed
    cout<<"How much do you weigh in pounds?"<<endl;
    cin>>weight;
    cout<<"What was the intensity level of your physical activity?"<<endl;
    cin>>intense;
    cout<<"How many minutes did you perform the physical activity?"<<endl;
    cin>>minutes;
    cout<<"How many calories per serving did you consume of your favorite food?"<<endl;
    cin>>calorie;
    
    //Output the results
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Calories Required to Maintain Body Weight"<<endl<<endl;
    cout<<"  From BMR                = "<<getBMR(weight)<<" calories"<<endl;
    cout<<"  From Physical Activity  = "<<getPhys(weight,intense,minutes)<<" calories"<<endl;
    cout<<"  From Calories Consumed  = "<<getCons(calorie)<<" calories"<<endl;
    cout<<"  Total Calories Required = "<<getBMR(weight)+getPhys(weight,intense,minutes)+
                                          getCons(calorie)<<" calories"<<endl;
    cout<<endl<<"That is a total of "<<(getBMR(weight)+getPhys(weight,intense,minutes)+
                                          getCons(calorie))/calorie<<" servings of your favorite food a day"<<endl;
    
    //Exit Stage Right!
    return 0;
}

/**********************************
 ************* getCons ************
 **********************************
 * Purpose: To get calories required from calories consumed
 * Input:
 *      calorie -> c
 * Output:
 *      calrie  -> total amount of calories from eating
 *********************************/
float getCons(unsigned int c){
    float calrie;   //calories consumed
    calrie=c*0.1;
    return calrie;
}

/**********************************
 ************* getPhys ************
 **********************************
 * Purpose: To get calories required from physical activity
 * Input:
 *      weight  -> w
 *      intense -> i
 *      minutes -> m
 * Output:
 *      physAct -> calories required from physical activity
 *********************************/
float getPhys(unsigned int w,unsigned int i,unsigned int m){
    float physAct;
    physAct=0.0385*i*w*m;
    return physAct;
}

/**********************************
 ************* getBMR *************
 **********************************
 * Purpose: To get calories required from BMR
 * Input:
 *      weight -> w
 * Output:
 *      bmr    -> calories required from BMR
 *********************************/
float getBMR(unsigned int w){
    float bmr;
    bmr=70*pow((w/2.2),0.756);
    return bmr;
}
