/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 8, 2015, 5:43 PM
 * Purpose: Average Rainfall
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    
    //Declare Variables
    float nYears;           //number of years in the cycle for the collection of data
    unsigned int nMonths=0; //number of months the cycle took to complete
    float rainfal;          //amount of rainfall for the month in inches (in)
    float average;          //total average rainfall in inches (in)
    float tRnfall;          //total sum of rainfall in inches (in)
    
    //Input number of years the data was collected
    cout<<"Over the course of how many years was the data collected?"<<endl;
    cin>>nYears;
    cout<<endl;
    
    //Validation: You can't have zero or a negative number of years
    if(nYears<1){  
        do{
            cout<<"You can't have zero or a negative number of years"<<endl;
            cout<<"Over the course of how many years was the data collected?"<<endl;
            cin>>nYears;
            cout<<endl;
            
        }while(nYears<1);
    }
    //Loop for the number of years
    for(unsigned int years=1;years<=nYears;years++){
        
        //Loop to input the inches of rainfall per month
        for(unsigned int months=1;months<=12;months++){
            cout<<"How many inches of rainfall was in month "<<months<<" of year "<<years<<"?"<<endl;
            cin>>rainfal;
            cout<<endl;
            
            //Validation: You can't have a negative number of inches (0 is ok)
            if(rainfal<0){
                do{
                    cout<<"You can't have a negative number of inches of rainfall (zero is ok)"<<endl;
                    cout<<"How many inches of rainfall was in month "<<months<<" of year "<<years<<"?"<<endl;
                    cin>>rainfal;
                    cout<<endl;
                    
                }while(rainfal<0);
            }
            
            //calculating the rainfall for each progressive month
            tRnfall+=rainfal;
            nMonths++;
        }
    }
    
    //calculate rainfall average
    average=tRnfall/nMonths;
    
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"The total rainfall in "<<nMonths<<" months is "<<tRnfall<<"(in)"<<endl;
    cout<<"The average rainfall per month is "<<average<<"(in)"<<endl;
    
    //Exit Stage Right!
    return 0;
}

