/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 11, 2015, 4:01 PM
 * Purpose: Deep Fried Twinkie vending machine
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
float ttlMny(float);
float outProd(float);


//Execution Begins Here!
int main(int argc, char** argv) {
    
    //Declare Variables
    float total=0.0f; //total $ amount inserted to machine
    short money;      //user input of coin
    
    //Loop to add money
    cout<<"Welcome to the Deep-Fry Twinkie Vending Machine"<<endl;
    cout<<"One Deep-Fried Twinkie is $3.50"<<endl;
        
    while (total<3.5f){
        cout<<"Insert Coins"<<endl;
        cout<<" 1. One Dollar"<<endl;
        cout<<" 2. One Quarter"<<endl;
        cout<<" 3. One Dime"<<endl;
        cout<<" 4. One Nickel"<<endl;
        cin>>money;

        switch(money){
            case 1: 
                total+=1.0f;
                break;
            case 2: 
                total+=0.25f;
                break;
            case 3: 
                total+=0.1f;
                break;
            case 4: 
                total+=0.05f;
                break;
            default: cout<<"Enter and appropriate amount of money"<<endl;
        }
        
        ttlMny(total);
    }
    
    //Output Change function
    outProd(total);
    
    //Exit Stage Right!
    return 0;
}

/*****************************************************************
 *********************  outProd  *********************************
 *****************************************************************
 * Purpose: to dish out the product and change
 * Input: 
 *      t -> total amount paid in $'s
 * Output:
 *      t -> change due in $'s
 ****************************************************************/
float outProd(float t){
    //Output your product
    cout<<"Enjoy your Deep-Fried Twinkie!"<<endl;
    
    //Calculate change
    t-=3.5f;
    
    //Output change
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Your Change = $"<<t<<endl;
}

/*****************************************************************
 *********************  addMny  **********************************
 *****************************************************************
 * Purpose: add to total amount insterted
 * Input: 
 *      m -> choice amount of money user inserted
 * Output:
 *      total -> total add so far
 ****************************************************************/
float ttlMny(float m){
    //Declare Variables
    float total=0.0f;
    
    //Calculate total
    total+=m;
    
    //Output the results
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Amount inserted = $"<<total<<endl;
}