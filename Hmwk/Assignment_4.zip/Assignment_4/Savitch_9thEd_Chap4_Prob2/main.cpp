/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 11, 2015, 1:56 PM
 * Puropose: to compute clothing size
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
float getHtSz(unsigned int,unsigned int);
float getJkSz(unsigned int,unsigned int,unsigned int);
float getWtSz(unsigned int,unsigned int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Delcare Variables
    unsigned int weight;  //User's weight input in pounds(lbs)
    unsigned int height;  //User's height input in inches(in)
    unsigned int age;     //User's age in years(yrs)
    
    //User input of weight and height
    cout<<"How much do you weigh in pounds?"<<endl;
    cin>>weight;
    cout<<"How tall are you in inches?"<<endl;
    cin>>height;
    cout<<"What is your age in years?"<<endl;
    cin>>age;
    cout<<endl;
    
    //Output the sizes
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Hat Size    = "<<getHtSz(weight,height)<<endl;
    cout<<"Jacket Size = "<<getJkSz(weight,height,age)<<"in"<<endl;
    cout<<"Waist Size  = "<<getWtSz(weight,age)<<"in"<<endl;
    
    //Exit Stage Right!
    return 0;
}

/*****************************************************
 ********************** getWtSz **********************
 *****************************************************
 * Purpose: To get waist size
 * Input:
 *      weight -> w -> weight in lbs
 *      age    -> a -> age in years
 * Output:
 *      ttlAdd  -> amount being added to waist size
 *      wstSize -> total waist size in inches
 ****************************************************/
float getWtSz(unsigned int w,unsigned int a){
    float wstSize=w/5.7;
    float ttlAdd;
    
    if(a>28){
        ttlAdd=(a-28)/2;
        ttlAdd*=0.1f;
        wstSize+=ttlAdd;
    }
    
    return wstSize;
}

/*****************************************************
 ********************** getJkSz **********************
 *****************************************************
 * Purpose: To get chest size in inches for jacket
 * Input:
 *      weight -> w -> weight in lbs
 *      height -> h -> height in inches
 *      age    -> a -> age in years
 * Output:
 *      jckSize -> jacket size in inches
 ****************************************************/
float getJkSz(unsigned int w,unsigned int h,unsigned int a){
    //Calculate chest size for jacket
    float jckSize=(w*h)/288.0f;
    if(a>=40){
        a/=10;
        if(a==4) a=1;
        if(a==5) a=2;
        if(a==6) a=3;
        if(a==7) a=4;
        if(a==8) a=5;
        if(a==9) a=6;
        if(a==10) a=7;
        if(a==11) a=8;

        jckSize+=(1/8.0f*a);
    }
    return jckSize;
}

/*****************************************************
 ********************** getHtSz **********************
 *****************************************************
 * Purpose: To get the hat size
 * Input:
 *      weight -> w -> weight in lbs
 *      height -> h -> height in inches
 * Output:
 *      hatSize -> hat size
 ****************************************************/
float getHtSz(unsigned int w,unsigned int h){
    //Calculate Hat Size
    float hatSize=(static_cast<float>(w)/h)*2.9;
    
    return hatSize;
}