/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 8, 2015, 4:23 PM
 * Purpose: Hotel Occupancy
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Define Variables
    unsigned int nFloors;  //number of floors a hotel has
    unsigned int nRooms;   //number of rooms a floor has
    unsigned int nOccpd;   //number of rooms on a floor that are occupied
    unsigned int tRooms=0; //total number of rooms a hotel has
    unsigned int tOccpd=0; //total number of rooms occupied in a hotel
    unsigned int tAvail;   //total number of rooms available in the hotel
    float pOccpd;          //percentage of occupied rooms
    
    //Input of how many floors the hotel has
    cout<<"Welcome."<<endl;
    cout<<"How many floors do you have in your hotel?"<<endl;
    cin>>nFloors;
    cout<<endl;
    
    //Validation: You can't have a negative number of floors
    if(nFloors>=1){
        
        //Loop of number of rooms and number of occupied rooms per floor
        for(unsigned int floors=1;floors<=nFloors;floors++){
            
            if(floors==13)floors++;//skips floor 13
            
            //Input of how many rooms
            cout<<"How many rooms are on floor "<<floors<<"?"<<endl;
            cin>>nRooms;
            cout<<endl;
            
            //Validation: You can't have less than 10 rooms per floor in a hotel
            if(nRooms<10){
                do{
                    cout<<"You can't have less than 10 rooms per floor"<<endl;
                    cout<<"How many rooms are on floor "<<floors<<"?"<<endl;
                    cin>>nRooms;
                    
                }while(nRooms<10);
                
                
            }
            
            //Input of how many rooms are occupied
            cout<<endl<<"How many of those are occupied?"<<endl;
            cin>>nOccpd;
            cout<<endl;
            
            //Validation: You can't have more rooms occupied than there are rooms
            if(nOccpd>nRooms){
                do{
                    cout<<"You can't have more rooms occupied than there are rooms"<<endl;
                    cout<<"How many rooms are occupied on floor "<<floors<<"?"<<endl;
                    cin>>nOccpd;
                    cout<<endl;
                }while(nOccpd>nRooms);
            }
            
            //adding rooms of each floor
            tRooms+=nRooms;
            tOccpd+=nOccpd;
        }
        
    }else {
        cout<<"You can't have a negative number of floors."<<endl;
        return 1;
    }
    
    //Calculating the percentage of occupied rooms in the hotel
    pOccpd=static_cast<float>(tOccpd)/tRooms;
    
    //Calculating rooms available
    tAvail=tRooms-tOccpd;
    
    //Output the results
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Out of a total of "<<tRooms<<" rooms, "<<tAvail<<" rooms are available,"<<endl;
    cout<<"and "<<tOccpd<<" rooms are occupied."<<endl;
    cout<<"That is "<<pOccpd*100<<"% of the rooms occupied in your hotel."<<endl;
    
    //Exit Stage Right!
    return 0;
}

