/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 11, 2015, 10:30 PM
 * Purpose: Time Travel
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
int getDiff(unsigned int,unsigned int,char,
            unsigned int,unsigned int,char);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int pHours; //Present time of hours
    unsigned int pMinute;//Present time of minutes
    unsigned int fHours; //Future time of hours
    unsigned int fMinute;//Future time of minutes
    char isPAM;          //Is present AM or PM?
    char isFAM;          //Is future AM or PM?
    
    //User Input of present time and future time
    cout<<"Are you ready for an adventure?!"<<endl;
    cout<<"Our time machine is ready to be used!"<<endl;
    cout<<"What is the present time?"<<endl;
    cout<<"Examples of input are 11 59 A or 12 01 P"<<endl;
    cin>>pHours>>pMinute>>isPAM;
    
    cout<<"What time in the future do you want to reach?"<<endl;
    cout<<"The time machine doesn't have a lot of juice left,"<<endl;
    cout<<"so you can only go as far as 24 hours in advance."<<endl;
    cout<<"Again, Examples of input are 11 59 A or 12 01 P"<<endl;
    cin>>fHours>>fMinute>>isFAM;
    
    
    cout<<"You will now travel "<<getDiff(pHours,pMinute,isPAM,fHours,fMinute,isFAM);
    cout<<" minutes into the future! Enjoy the adventure!"<<endl;
    return 0;
}
 /****************************************************
  ******************  getDiff  ***********************
  ****************************************************
  * Purpose: To calculate the time difference
  * Input:
  *     pHours  -> ph
  *     pMinute -> pm
  *     isPAM   -> p
  *     fHours  -> fh
  *     fMinute -> fm
  *     isFAM   -> f
  * Output:
  *     total   -> total minute differential
  */
int getDiff(unsigned int ph,unsigned int pm,char p,
            unsigned int fh,unsigned int fm,char f){
    unsigned int pTotal; //Present total time in minutes
    unsigned int fTotal; //Future total time in minutes
    unsigned int total;  //total minutes
    
    ph*=60;
    fh*=60;
    pTotal=ph+pm;
    fTotal=fh+fm;
    
    //Calculating AM -> AM or PM -> PM
    if(p=='A'||p=='a' && f=='A'||f=='a'){
        if(pTotal>fTotal){
            total=pTotal-fTotal;
            total=1440-total;
        }else{
            total=fTotal-pTotal;
        }
    }
    if(p=='P'||p=='p' && f=='P'||f=='p'){
        if(pTotal>fTotal){
            total=pTotal-fTotal;
            total=1440-total;
        }else{
            total=fTotal-pTotal;
        }
    }
    
    //Calculating AM -> PM or PM -> AM
    if(p=='A'||p=='a' && f=='P'||f=='p'){
        if(pTotal>fTotal){
            total=pTotal-fTotal;
            total=720-total;
        }else{
            total=fTotal-pTotal;
        }
    }
    if(p=='P'||p=='p' && f=='A'||f=='a'){
        if(pTotal>fTotal){
            total=pTotal-fTotal;
            total=720-total;
        }else{
            total=fTotal-pTotal;
        }
    }
    return total;
}