/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 11, 2015, 3:48 PM
 * Purpose: to sing the 99 bottles song
 */

//System Libraries
#include <cstdlib>
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
string whleNum(int);
string frstNum(int);
string secNum(int);
string teens(int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Loop to count down in the song
    for(int i=99; i>=0; i--){
        if(i!=99){
            cout<<whleNum(i)<<" bottles of beer on the wall."<<endl<<endl;
        }
        if(i==0){
            cout<<"Zero bottles of beer on the wall"<<endl<<endl;
            return 0;
        }
        cout<<whleNum(i)<<" bottles of beer on the wall"<<endl;
        cout<<whleNum(i)<<" bottles of beer"<<endl;
        cout<<"You take one down pass it around"<<endl;
    }
    return 0;
}

/**************************************
 ************ whleNum *****************
 **************************************
 * Purpose: to get the whole number
 * Input: 
 *      i -> n (from the for-loop)
 * Output:
 *      ret -> the whole number
 *************************************/
string whleNum(int n){
    string ret="";
    int a=n/10;
    ret += frstNum(a);
    a=n%10;
    if(ret=="Special"){
        ret=teens(n);
    }if(ret=="No num"){
        string temp = secNum(a);
        ret ="";
        for(int i=1; i<temp.size(); i++){
            ret+=temp[i];
        }
    }else{
    ret+=secNum(a);
    }
    if(n==0)return "Zero";
    return ret;
}

/**************************************
 ************ frstNum *****************
 **************************************
 * Purpose: to get the number in the 10's place
 * Input: 
 *      a -> n (dividing by 10)
 * Output:
 *      return -> string
 *************************************/
string frstNum(int n){
    
    if(n==1){
        return "Special";
    }if(n==2){
        return "Twenty";
    }if(n==3){
        return "Thirty";
    }if(n==4){
        return "Fourty";
    }if(n==5){
        return "Fifty";
    }if(n==6){
        return "Sixty";
    }if(n==7){
        return "Seventy";
    }if(n==8){
        return "Eighty";
    }if(n==9){
        return "Ninety";
    }
    return "No num";
}

/**************************************
 ************* secNum *****************
 **************************************
 * Purpose: to get the number in the 1's place
 * Input: 
 *      a -> n (modulus by 10)
 * Output:
 *      return -> string
 *************************************/
string secNum(int n){
    if(n==0){
        return "";
    }if(n==1){
        return "-One";
    }if(n==2){
        return "-Two";
    }if(n==3){
        return "-Three";
    }if(n==4){
        return "-Four";
    }if(n==5){
        return "-Five";
    }if(n==6){
        return "-Six";
    }if(n==7){
        return "-Seven";
    }if(n==8){
        return "-Eight";
    }if(n==9){
        return "-Nine";
    }
    return "no num";
}

/**************************************
 ************** teens *****************
 **************************************
 * Purpose: to get the number between 11-19
 * Input: 
 *      a -> n (special case)
 * Output:
 *      return -> string
 *************************************/
string teens(int n){
    if(n==10){
        return "Ten";
    }
    if(n==19){
        return "Nineteen";
    }
    if(n==18){
        return "Eighteen";
    }
    if(n==17){
        return "Seventeen";
    }
    if(n==16){
        return "Sixteen";
    }
    if(n==15){
        return "Fifteen";
    }
    if(n==14){
        return "Fourteen";
    }
    if(n==13){
        return "Thirteen";
    }
    if(n==12){
        return "Twelve";
    }
    if(n==11){
        return "Eleven";
    }
}
