/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on July 8, 2015, 10:45 AM
 * Purpose: Retirement Calculator
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes
void heading();
float rtirmnt(unsigned int,float,float,float,float,float,float,unsigned int,float);
void table(unsigned int,unsigned int,float,float,float);


//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float salary=90000.0f; //Average Salary
    float invRate=0.05f;//Investment Rate -> see Calif Muni Bonds
    float savReq;       //Savings required at retirement
    float pDep=0.20f;   //Of your gross Salary -> percentage deposited
    float deposit;      //Yearly deposit in $'s
    float savings=0.0f;    //Initial Savings at start of employment
    unsigned int year=0;       //Start at year 0
    unsigned int date=18;
    float intrst=0;
    
    //Calculate required savings
    savReq=salary/invRate;
    
    heading();
    rtirmnt(year,savings,deposit,pDep,invRate,salary,savReq,date,intrst);
    //table(year,date,savings,intrst,deposit);
    
    return 0;
}

/**********************************************************
*********************  heading  ***************************
***********************************************************
 * Purpose: Output the heading of our table
**********************************************************/
void heading(){
    cout<<"Year    Date        Savings     Interest     Deposit"<<endl;
    cout<<"-----------------------------------------------------"<<endl;
}

/**********************************************************
**********************  rtirmnt ***************************
***********************************************************
 * Purpose: to calculate your retirement
 * Input
 *      year    -> current year
 *      savings -> savings for the year
 *      deposit -> amount deposited in that year
 *      pDep    -> percent deposit
 *      invRate -> investment rate
 *      salary  -> salary per year
 *      savReq  -> savings required
**********************************************************/
float rtirmnt(unsigned int year,float savings,float deposit, float pDep,float invRate,float salary,float savReq,unsigned int date,float intrst){
    
    //Loop to calculate when retirement is possible
    do{
        deposit=pDep*salary; //Deposit based on salary
        intrst=savings*invRate;
        table(year,date,savings,intrst,deposit);
        savings*=(1+invRate);//Earning based upon investment rate
        savings+=(deposit);  //Add the deposit after earning interest
        year++;
        date++;
        
    }while(savings<savReq);//When we have enough to retire then exit loop
    
    table(year,date,savings,intrst,deposit);
    
}

/**********************************************************
*********************  heading  ***************************
***********************************************************
 * Purpose: Output the table
 * Output
 *      year  -> current year
 *      date  -> date within the year
 *      savings -> total savings per year in $'s
 *      intrst  -> interest earned in $'s
 *      deposit -> deposit per year in $'s
**********************************************************/
void table(unsigned int year,unsigned int date,float savings,float intrst,float deposit){
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<setw(2)<<year<<"    06/01/"<<date<<"   $"<<setw(10)<<savings<<"   $"<<setw(8)<<intrst<<"   $"<<deposit<<endl;
}