/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on June 24, 2015, 1:19 PM
 * Purpose: Lab, Gas Tax
 */

#include <iostream> //I/O Library
using namespace std; //Standard namespace

//User Libraries

//Global Constants

//Function Prototypes

int main(int argc, char** argv) {
    //Declare Variables
    float perGal;          //Price per Gallon in $'s
    float baseGal;         //Base Price minus all tax in $'s
    float baseASl;         //Base Price after Sales Tax in $'s
    float fedTax;          //Federal Tax per gallon in $'s
    float cExTax;          //California Excise Tax in $'s
    float cSleTax;         //Percent California Sales Tax
    float salesTax;        //California Sales Tax in $'s
    unsigned short ptgTax;          //Percent of Total Tax paid
    
    //Initialize Variables
    perGal=3.69f;
    fedTax=0.18f;
    cExTax=0.38f;
    cSleTax=0.08f;
    
    //Calculate
    baseASl=perGal-fedTax-cExTax;
    baseGal=baseASl/(1+cSleTax);
    salesTax=perGal-baseGal;
    ptgTax=salesTax/perGal*100;
    
    //Output
    cout<<"The total tax paid from paying $3.69/gallon of gas is $"
        <<salesTax<<"."<<endl;
    cout<<"That is a total of "<<ptgTax<<"%!"<<endl;
    //Exit Stage Right!
    return 0;
}

