/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on June 23, 2015, 12:51 PM
 * Purpose: Homework, Energy Drinks
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;//Namespace for iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned short cSurv = 12467;//customers surveyed
    float pEDrnks = 0.14f;//percentage of people surveyed that drink energy drinks
    float pCDrnks = 0.64f;//percentage of energy drinkers that prefer citrus flavor
    unsigned short nEDrnks;        //number of energy drinkers
    unsigned short nCDrnks;        //number of energy drinkers that prefer citrus flavors
    //Calculate the number of energy drinkers
    nEDrnks = cSurv*pEDrnks;
    nCDrnks = nEDrnks*pCDrnks;
    //Output the results
    cout<<"Of the 12,467 Customers Surveyed,"<<endl;
    cout<<nEDrnks<<" were Energy Drinkers"<<endl;
    cout<<"and of those people, "<<nCDrnks<<" prefered citrus flavored energy drinks"<<endl;
    //Exit stage right!
    return 0;
}