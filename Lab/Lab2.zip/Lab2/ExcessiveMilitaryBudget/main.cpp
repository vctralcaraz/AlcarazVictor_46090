/* 
 * File:   main.cpp
 * Author: Victor Alcaraz
 * Created on June 23, 2015, 1:36 PM
 * Purpose: Lab, Excessive Military Budget
 */
//System Libraries
#include <iostream> //I/O Library
using namespace std;//Namespace for iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    float fedBudg = 3.9e12;//Federal Budget for 2015
    float milBudg = .598e12;//Military Budget for 2015
    float pMlBudg;//Percent of the military budget from the federal budget
    //Calculate the free-fall distance
    pMlBudg = milBudg/fedBudg*100;
    //Output the results
    cout<<"The military's budget is "<<pMlBudg<<"% of the Federal Budget in 2015!"<<endl;
    //Exit stage right!
    return 0;
}