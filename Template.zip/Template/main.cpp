
//System Libraries
#include <iostream>//I/O Library
using namespace std;//Standard namespace for iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables

    //Exit Stage Right!
    return 0;
}

